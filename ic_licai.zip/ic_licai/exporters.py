from typing import Dict, Any, List
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from reportlab.lib.colors import black, HexColor
from openpyxl import Workbook
import io, json, datetime

PRIMARY = HexColor("#0A2640")

def export_pdf(data: Dict[str, Any]) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4

    def header(title):
        c.setFillColor(PRIMARY)
        c.setFont("Helvetica-Bold", 16)
        c.drawString(2*cm, h-2*cm, title)
        c.setFillColor(black)
        c.setFont("Helvetica", 9)
        c.drawString(2*cm, h-2.5*cm, f"Generated {datetime.datetime.utcnow().isoformat()} (UTC) • IC‑LicAI Demo")
        c.line(2*cm, h-2.7*cm, w-2*cm, h-2.7*cm)

    # Cover
    header("Intangible Capital & Licensing Readiness Report")
    c.setFont("Helvetica", 12)
    c.drawString(2*cm, h-4*cm, f"Case: {data.get('case','(unspecified)')}")
    c.drawString(2*cm, h-5*cm, "Executive Summary")
    c.setFont("Helvetica", 10)
    summary_text = data.get("summary","This advisory report summarises the organisation's intangible capital and licensing readiness.")
    # Wrap summary roughly
    for i, chunk in enumerate([summary_text[i:i+100] for i in range(0, len(summary_text), 100)]):
        c.drawString(2*cm, h-5.7*cm - i*0.45*cm, chunk)
    c.showPage()

    # IC Map
    header("Intangible Capital Map (4-Leaf)")
    y = h-4*cm
    for leaf, items in data.get("ic_map", {}).items():
        c.setFont("Helvetica-Bold", 11)
        c.drawString(2*cm, y, f"• {leaf}")
        y -= 0.6*cm
        c.setFont("Helvetica", 10)
        for it in items[:6]:
            c.drawString(2.6*cm, y, f"- {it}")
            y -= 0.5*cm
        y -= 0.3*cm
        if y < 4*cm:
            c.showPage(); header("Intangible Capital Map (cont.)"); y = h-4*cm

    # Readiness
    c.showPage()
    header("10‑Steps Readiness Summary")
    y = h-4*cm
    for row in data.get("readiness", []):
        c.setFont("Helvetica-Bold", 10); c.drawString(2*cm, y, f"Step {row['step']}: {row['name']} (score {row['score']}/3)")
        y -= 0.5*cm; c.setFont("Helvetica", 10)
        for t in row["tasks"]:
            c.drawString(2.6*cm, y, f"- {t}"); y -= 0.45*cm
        y -= 0.2*cm
        if y < 3.5*cm:
            c.showPage(); header("10‑Steps Readiness (cont.)"); y = h-4*cm

    # Licensing
    c.showPage()
    header("Licensing Options (advisory)")
    y = h-4*cm
    for opt in data.get("licensing", []):
        c.setFont("Helvetica-Bold", 11); c.drawString(2*cm, y, f"• {opt['model']}")
        y -= 0.5*cm; c.setFont("Helvetica", 10)
        c.drawString(2.6*cm, y, f"{opt['notes']}"); y -= 0.6*cm
        if y < 4*cm:
            c.showPage(); header("Licensing Options (cont.)"); y = h-4*cm

    # Audit note
    c.showPage()
    header("Governance & Audit Note")
    c.setFont("Helvetica", 10)
    c.drawString(2*cm, h-4*cm, "This report is generated using an advisory‑first workflow with human approval. Evidence sources and decisions are auditable.")
    c.save()
    buf.seek(0)
    return buf.getvalue()

def export_xlsx(ic_map: Dict[str, List[str]]) -> bytes:
    wb = Workbook(); ws = wb.active; ws.title = "IA Register"
    ws.append(["Asset Name","Capital Type","Tacit/Explicit","Evidence Source","IAS 38 Status","Priority","Next Step"])
    for leaf, items in ic_map.items():
        for it in items:
            ws.append([it, leaf, "", "", "", "", ""])
    bio = io.BytesIO(); wb.save(bio); bio.seek(0); return bio.getvalue()

def export_json(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, indent=2).encode("utf-8")
